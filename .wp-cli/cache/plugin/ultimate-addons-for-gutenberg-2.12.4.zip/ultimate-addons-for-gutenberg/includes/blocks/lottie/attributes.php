<?php
/**
 * Attributes File.
 *
 * @since 2.0.0
 *
 * @package uagb
 */

return array(
	'block_id'         => '',
	'jsonLottie'       => '',
	'lottieURl'        => '',
	'lottieSource'     => '',
	'height'           => '',
	'heightTablet'     => '',
	'heightMob'        => '',
	'width'            => '',
	'widthTablet'      => '',
	'widthMob'         => '',
	'backgroundColor'  => '',
	'backgroundHColor' => '',
	'loop'             => true,
	'speed'            => 1,
	'reverse'          => false,
	'playOn'           => 'none',
);
