=== Contact Form by WPForms - Drag & Drop Form Builder for WordPress ===
Contributors: wpforms, jaredatch, smub, slaFFik
Tags: contact form, contact form plugin, forms, form builder, custom form
Requires at least: 5.5
Tested up to: 6.4
Stable tag: 1.8.7.2
Requires PHP: 7.0
License: GNU General Public License v2.0 or later

The best WordPress contact form plugin. Drag & Drop form builder to create beautiful contact forms, payment forms, & other custom forms in minutes.



== Description ==

= WordPress Contact Form Builder Plugin =

[WPForms](https://wpforms.com/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) is a drag & drop WordPress form builder that's EASY and POWERFUL. Create contact forms, feedback forms, subscription forms, payment forms, and other types of forms for your site in minutes, not hours!

At WPForms, user experience is our #1 priority. Our pre-built form templates and workflows make WPForms the most beginner-friendly contact form plugin on the market. You don’t have to hire a developer. Create a form in less than 5 minutes or use a template to get a head start.

> <strong>WPForms Pro</strong><br />
> This plugin is the Lite version of WPForms Pro, which comes with email subscription forms, multi-page contact forms, file uploads, conditional logic, and extra payment integrations. [Click here to purchase the best premium WordPress contact form plugin now!](https://wpforms.com/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)

https://www.youtube.com/watch?v=Ypl0XcGphw8&rel=0

= Drag & Drop Contact Form Builder =

Create custom contact forms in minutes with our easy-to-use [drag and drop online form builder](https://wpforms.com/features/drag-drop-online-form-builder/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin). But don't just take our word for it. See what WordPress experts are saying:

> WPForms is by far the <strong>easiest form plugin to use</strong>. My clients love WPForms and it's one of the few plugins they can use without any training. As a developer I appreciate how fast, modern, clean and extensible it is.<br>
> Bill Erickson - Expert WordPress Consultant

= Pre-built Form Templates =

WPForms comes with [1500+ pre-built form templates](https://wpforms.com/templates/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin).

Whether you're looking to create a simple contact form, marketing form, request a quote form, donation form, payment order form, registration form, or a subscription form, we have a form template already prepared and ready to use.

= Mobile Ready, SEO Friendly, and Optimized for Speed =

WPForms contact forms are 100% responsive and mobile-friendly. We optimized every query on the frontend and the backend to ensure that it’s one of the fastest WordPress contact form plugins.

You can embed your contact form on any page with an optimized title and description, so WPForms is one of the most SEO friendly contact form plugins too.

= Fields & Features You Need to Succeed =

With star ratings, file uploads, and multi-page contact forms, you can easily integrate your contact forms with an email marketing service or collect payments for bookings and orders.

See what one business owner has to say about their WPForms contact form:

>As a business owner, time is my most valuable asset. WPForms allows me to create smart contact forms with just a few clicks. With their pre-built form templates and the drag & drop builder, I can create a new form that works in less than 2 minutes without writing a single line of code. Well worth the investment.<br>
> David Henzel - Co-founder of MaxCDN

= Surveys & Polls =

Create custom survey forms like Survey Monkey. Our [WordPress survey plugin addon](https://wpforms.com/features/surveys-and-polls-addon?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) comes with smart survey fields including Likert scale, star ratings, and NPS. Embed your surveys and polls anywhere in WordPress.

Use our survey reporting tools to customize graphs, export them for presentations, and display aggregate results. You can also share poll results instantly when collecting votes.

= Default WordPress Forms =

Aside from building simple contact forms, WPForms also helps you create better default WordPress forms, like custom WordPress login forms and custom WordPress user registration forms. Create a password-protected contact form or even a members-only contact form.

Bloggers and publishers can use our WordPress post submission forms to accept guest posts, testimonials, and more.

= Payment Forms, Donation Forms, Booking Forms, and More =

While WPForms started out as a contact form plugin, it has evolved into a powerful custom forms solution for any type of payment or booking form.

WPForms integrates with PayPal, Stripe, Square, and Authorize.Net so you can easily accept credit card payments or take payments via PayPal, and you can also take signatures.

= Custom Calculator Forms =

Using the [WPForms Calculations addon](https://wpforms.com/features/calculations-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin), you can build custom formulas and display results on the frontend.

Create simple arithmetic calculations or build complex conditional calculations with rounded values, averages, time ranges, and more! It’s the best calculator plugin for WordPress.

= Forms Optimized for Conversions =

With our Form Pages addon, you can create distraction-free custom form landing pages to increase conversions.

To improve form completion rates, we created Conversational Forms&reg; which helps you make your feedback forms feel more human by adding an interactive layout. ([See Conversational Forms Demo](https://wpforms.com/addons/conversational-forms-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)).

= Easy to Customize and Extend =

You can easily customize your contact forms with our section dividers, HTML blocks, and CSS. Embedding forms in Elementor and Divi has never been easier thanks to our native integrations.

We also knew that our developer friends may want more control, so we added tons of hooks and filters.

= Full WPForms Feature List =

* [Online form builder](https://wpforms.com/features/drag-drop-online-form-builder/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) - powerful drag & drop contact form builder. Create WordPress contact forms and other online forms without writing any code.
* 100% mobile responsive.
* GDPR friendly.
* [Form templates](https://wpforms.com/templates/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) pre-built and ready to import.
* [Form styling](https://wpforms.com/docs/styling-your-forms/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) for fields, labels, and buttons.
* [Spam protection](https://wpforms.com/features/spam-protection/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) built in, plus integrations with hCaptcha, Google reCAPTCHA, and Cloudflare Turnstile.
* [Instant form notifications](https://wpforms.com/features/instant-notifications/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) via email.
* [Custom form confirmations](https://wpforms.com/features/form-confirmation/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) with success messages or thank you pages.
* [Smart phone field](https://wpforms.com/docs/how-to-choose-the-right-form-field-for-your-forms/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin#phone) that adapts to your visitor's location.
* [Coupons](https://wpforms.com/addons/coupons-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) for free shipping and sale discounts.
* [Calculator forms](https://wpforms.com/features/calculations-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) for payment, shipping, billing, and more.
* [File upload fields](https://wpforms.com/features/file-uploads/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) for user submissions.
* [Multi-page forms](https://wpforms.com/features/multi-page-forms/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) with progress bars.
* [Smart conditional logic](https://wpforms.com/features/conditional-logic/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to show or hide fields.
* [Signatures](https://wpforms.com/addons/signature-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) for agreements or payment forms.
* [User registration forms](https://wpforms.com/features/user-registration/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) and custom login forms.
* [Post submission forms](https://wpforms.com/features/post-submissions/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to collect user-generated content.
* [Geolocation](https://wpforms.com/features/geolocation-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to collect location data along with submissions.
* [Surveys and Polls](https://wpforms.com/features/surveys-and-polls-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) with interactive reports.
* [Form abandonment detection](https://wpforms.com/features/form-abandonment/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to collect partial form submissions.
* [Form locker](https://wpforms.com/addons/form-locker-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to control access using passwords, dates, and more.
* [Offline forms](https://wpforms.com/addons/offline-forms-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to collect submissions without an internet connection.
* [Form landing pages](https://wpforms.com/features/form-pages-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to boost conversions.
* [Conversational forms](https://wpforms.com/addons/conversational-forms-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to boost overall completion rates.
* [Lead forms](https://wpforms.com/addons/lead-forms-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to get more submissions with multi-step layouts.
* [Webhooks](https://wpforms.com/addons/webhooks-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to send data without third party connectors.
* [User Journey reports](https://wpforms.com/features/user-journey-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) so you know which content is driving form conversions.
* [Save and Resume](https://wpforms.com/addons/save-and-resume-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to let visitors save and come back later.

= Integrations =

* [Google Sheets](https://wpforms.com/addons/google-sheets-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Zapier](https://wpforms.com/features/zapier-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [PayPal Standard](https://wpforms.com/addons/paypal-standard-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) and [PayPal Commerce](https://wpforms.com/features/paypal-commerce/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Stripe](https://wpforms.com/addons/stripe-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Square](https://wpforms.com/features/square-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Authorize.Net](https://wpforms.com/addons/authorize-net-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Mailchimp](https://wpforms.com/features/mailchimp-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [AWeber](https://wpforms.com/addons/aweber-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Campaign Monitor](https://wpforms.com/addons/campaign-monitor-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [GetResponse](https://wpforms.com/addons/getresponse-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Constant Contact](https://wpforms.com/features/constant-contact/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Drip](https://wpforms.com/features/drip-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [ActiveCampaign](https://wpforms.com/addons/activecampaign-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [HubSpot](https://wpforms.com/addons/hubspot-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Brevo](https://wpforms.com/features/brevo-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [MailerLite](https://wpforms.com/addons/mailerlite-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [ConvertKit](https://wpforms.com/features/convertkit-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Salesforce](https://wpforms.com/addons/salesforce-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)

You can see why WPForms is the best WordPress contact form plugin on the market! Want to unlock these features? [Upgrade to our Pro version](https://wpforms.com/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin).

= Credits =

This plugin is created by [Jared Atchison](https://www.jaredatchison.com/) and [Syed Balkhi](https://syedbalkhi.com/).

= Branding Guidelines =

WPForms&reg; is a registered trademark of WPForms LLC. When writing about the contact form plugin by WPForms, please make sure to uppercase the initial 3 letters.

* WPForms (correct)
* WP Forms (incorrect)
* wpforms (incorrect)
* wpform (incorrect)

== Installation ==

1. Install WPForms Lite either via the WordPress.org plugin repository or by uploading the files to your server. (See instructions on [how to install a WordPress plugin](https://www.wpbeginner.com/beginners-guide/step-by-step-guide-to-install-a-wordpress-plugin-for-beginners))
2. Activate WPForms Lite.
3. Navigate to the WPForms tab at the bottom of your admin menu and click the "Add New" button to begin creating your new WordPress contact form.
4. Want more features? [Purchase the full version of WPForms](https://wpforms.com/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)!

== Screenshots ==

1. WPForms Drag & Drop Online Form Builder
2. Adding New Field
3. Form Templates
4. Payments Overview
5. Single Payment Page
6. Form Preview
7. Form Pages with multiple styles
8. Conversational Forms

== Frequently Asked Questions ==

= Who should use WPForms? =

WPForms is perfect for business owners, bloggers, designers, developers, photographers, and basically everyone else. If you want to create a custom WordPress form, then you need to use the WPForms drag & drop form builder.

= Do I need to have coding skills to use WPForms? =

Absolutely not. You can create and manage forms without any coding knowledge (100% drag & drop form builder). WPForms is the most beginner friendly contact form plugin on the market.

= What type of WordPress forms can I build with WPForms? =

WPForms drag & drop form builder combined with our addons is the most powerful WordPress contact form plugin on the market. Here are some types of WordPress forms you can create:

* Simple Contact Forms
* Job Application Contact Form
* Feedback Survey Contact Form
* Make a Suggestion Contact Form
* Change Request Forms
* Online Booking Forms
* Event Booking Form
* Video Release Forms
* PTO Request Contact Form
* Maintenance Request Contact Form
* Scholarship Application Forms
* File Download Forms
* Employment Verification Forms
* Make a Referral Contact Form
* Volunteer Registration Contact Form
* Offline Contact Form

To see a full list, visit our [Form Template Gallery](https://wpforms.com/templates/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) which has over 1100+ pre-made contact form templates.

= Which Form Fields Does WPForms offer? =

We made WPForms form builder to be both easy and powerful.

Here are the contact form fields that comes with WPForms Form Builder (also known as Standard Fields):

* Text Field
* Paragraph Text (Textarea)
* Dropdown Field
* Multiple Choice (Radio Buttons)
* Checkboxes
* Numbers Field
* Name Field
* Email Address Field
* Number Slider Field

Here is a list of our advanced contact form builder fields (Fancy Fields):

* Smart Phone Field with international format verification
* Address Field
* Date / Time Field
* Website / URL Field
* File Upload - Great for File Upload Form
* Password Field
* Rich Text - Add a WYSIWYG field, perfect for guest blog post forms
* Layout Field - Position form fields inside columns using custom or premade layouts
* Page Break Field - Great for Multi-Page Contact Form with Progress Bar
* Section Divider - Great for Long Contact Forms
* HTML Field - add Custom HTML inside your form
* Content Field - Add headings, lists, and media to your forms without writing code
* Entry Preview - Allow your form users to preview their form entries before they've submitted them
* Star Rating - Great for Survey Forms and Polls
* Hidden Field
* Questions CAPTCHA - Great for Preventing Contact Form Spam
* Math CAPTCHA - Great for Preventing Contact Form Spam
* Likert Scale - Great for Survey Forms
* Signature Field - Great for Contracts and Booking Forms
* Net Promoter Score (NPS Field) - Great for Survey Forms
* Google ReCAPTCHA - Great for Preventing Contact Form Spam
* hCAPTCHA - Great for Preventing Contact Form Spam
* Cloudflare Turnstile - Great for Preventing Contact Form Spam

Here is a list of our Payment Fields that will help you create a order form, donation form, booking form, and other payment forms:

* Single Item
* Multiple Items
* Checkbox Items
* Dropdown Items
* Total (Calculation Field)
* Credit Card (Stripe, Square, and Authorize.Net)
* PayPal

= Can I integrate WPForms with my CRM or Email Marketing Service? =

Yes, WPForms offers seamless integration with over 1,000+ popular [email marketing](https://www.wpbeginner.com/showcase/best-email-marketing-services/) and [CRM software](https://www.wpbeginner.com/showcase/best-crm-software-for-small-businesses-compared/).

You can easily send data from your contact form and other WordPress forms to your favorite CRM, email newsletter, and other marketing platforms.

Here is a list of our popular marketing integrations:

* Mailchimp
* Constant Contact
* AWeber
* Drip
* Campaign Monitor
* GetResponse
* ActiveCampaign
* Zapier
* Salesforce CRM
* Brevo (ex Sendinblue)
* MailerLite

Using our Zapier integration, you can easily connect WPForms with over 5,000+ marketing apps including:

* PipeDrive CRM
* Google Sheets
* Active Campaign
* Zoho CRM
* Zoho Mail
* Zoho Invoice
* Agile CRM
* Slack
* Trello
* Infusionsoft by Keap
* Microsoft Excel
* Dropbox
* HelpScout
* Zendesk
* Freshbooks
* Freshsales
* Intercom
* Click Funnels
* Microsoft Dynamics 365 CRM
* Capsule CRM
* Insightly CRM
* Printfection
* Acuity Scheduling
* Quickbooks Online

See all [WPForms Zapier Integrations](https://zapier.com/apps/wpforms/integrations).

Note: WPForms was voted Zapier's 6th fastest growing app in the world.

= Can I create a Payment Form with WPForms? =

Yes, WPForms is not your average contact form plugin. You can use it to create any type of form including payment forms.

We make it easy for you to accept payments using Stripe, Square, Authorize.Net, and PayPal Commerce.

Both our Stripe and Authorize.Net integrations help you easily accept credit card payments online.

Our PayPal integration allows you to accept PayPal payments online.

= Can I Import / Export Forms with WPForms?

Yes, WPForms makes it easy to import / export your contact forms and other WordPress forms created with WPForms form builder. This is incredibly useful for developers and agencies who are building websites for clients.

You can also create custom form templates that you can use on client websites. For more see our documentation.

Aside from that, WPForms also allows you to import forms from other WordPress Contact Form plugins such as Contact Form 7, Ninja Forms, and Pirate Forms.

If you're not happy with your WordPress contact form plugin, then definitely give WPForms a try!

= I'd like access to all features. How can I get them? =

You can get access to more features, addons and support by [upgrading to our Pro version](https://wpforms.com/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin). Purchasing a Pro license gets you access to the full version of WPForms, automatic updates, priority support, and all WPForms Addons!

= Is WPForms translation ready? =

Yes, WPForms has full translation and localization support via the wpforms textdomain. Based on your site language, required .mo and .po translation files will be downloaded and placed into the default WordPress languages directory. The same is true for every WPForms Addon as well.

= Does WPForms include spam protection? =

Yes, WPForms includes spam protection which is enabled on all forms by default in the form settings.

Additionally, Google reCAPTCHA, hCaptcha and Cloudflare Turnstile are also supported and can be set up at WPForms > Settings > CAPTCHA.

WPForms is fully compatible with all versions of Google reCAPTCHA:

* Checkbox reCAPTCHA v2
* Invisible reCAPTCHA v2
* reCAPTCHA v3

Lastly, [Custom Captchas](https://wpforms.com/addons/custom-catpcha-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) are available which allow you to create math or question based captchas for your contact forms.

== Notes ==

WPForms is absolutely, positively the most [beginner friendly WordPress contact form plugin](https://wpforms.com/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) on the market. It is both easy and powerful.

We took the pain out of creating online forms and made it easy. Check out all [WPForms features](https://wpforms.com/features/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin).

Also, I'm the founder of [WPBeginner](https://www.wpbeginner.com/), the largest WordPress resource site for beginners. It was a huge priority for me to make a WordPress contact form plugin that beginners can use without any training.

I feel that we have done that here. I hope you enjoy using WPForms.

Thank you

Syed Balkhi

== Changelog ==

= 1.8.7.2 =
- Changed: "What's New" modal should be displayed based on the major version of the plugin.
- Changed: Improved Akismet integration efficiency.
- Fixed: Antispam token was passed as a simple form field, not protected from spam bots.
- Fixed: PHP warning was thrown in case of anonymous form submission when User ID smart tag was used.
- Fixed: Image positioning in the "What's New" blocks wasn't always correct.
- Fixed: Modal windows were not displayed on small screens.
- Fixed: The animation for opening the "What's New" modal worked improperly when the modal had small content.
- Fixed: The background was not entirely dimmed when scrolling the "What's New" popup.

= 1.8.7.1 =
- Added: The Announcements block in the Community page.
- Added: New way to expand the Form Templates subcategories list in the templates list sidebar.
- Added: New splash screen outlining notable features and changes in the release.
- Added: The user can see an overview of what they are purchasing by enabling the Order Summary for the Total payment field.
- Added: New `{order_summary}` smart tag.
- Changed: Improved compatibility with Twenty Twenty-Three theme.
- Changed: Improved plugin activation on WordPress multisite setups with both Lite and Pro versions installed.
- Changed: Improved support of sites hosted in the Azure platform using IIS.
- Changed: Updated DOMPurify library to 3.0.8.
- Changed: Removed `jquery-confirm` library in favor of jQuery.Confirm Reloaded drop-in replacement.
- Changed: Spam protection token is valid now for 3 days instead of 2.
- Changed: Spam protection token is no longer loaded with JS to avoid fails caused by script errors.
- Changed: Storing spam entries is now enabled by default for new forms.
- Changed: Users with limited capabilities are allowed to view the Forms Templates and Addons pages.
- Updated: `tijsverkoyen/css-to-inline-style` library to v2.2.7.
- Updated: `symphony/polyfill-iconv` library to v1.19.0.
- Updated: `symphony/polyfill-mbstring` library to v1.19.0.
- Updated: `woocommerce/action-scheduler` library to v3.7.1.
- Updated: `stripe/stripe-php` library to v13.9.0.
- Fixed: Some background actions could fail if triggered by WP-CLI via server cron.
- Fixed: Fatal error may occur in rare cases during migrations if they were triggered manually.
- Fixed: Read-only Number fields should not display spin buttons.
- Fixed: The Icons Choices field with a Large size was not centered in the Block Editor and Elementor.
- Fixed: Two messages appeared when clicking on the reCAPTCHA field after searching the fields in the Builder.
- Fixed: A form with a long title expanded the form selector dropdown in the Block Editor.
- Fixed: CSS Styles were not applied if Global Colors were already selected in Elementor Builder.
- Fixed: Payment method details were not stored for Stripe renewals.
- Fixed: The template page had style issues in the German language.
- Fixed: The Elementor popup preview had broken WPForms styles.
- Fixed: In some situations, payment amounts were improperly sanitized.
- Fixed: Some modals across the admin area were not responsive and did not fit on smaller screen sizes.
- Fixed: Templates' cache wasn't updated after the plugin update.
- Fixed: RTL support for WPForms Settings page.
- Fixed: RTL support for the Form Builder.
- Fixed: Some frontend fields were improperly rendered for RTL.
- Fixed: The user interface had different other issues when RTL language was in use.
- Fixed: The Form Builder settings screen had multiple visual issues when RTL language was used.
- Fixed: AJAX calls didn't work on servers with empty `$_SERVER['HTTP_REFERER']` value.
- Fixed: Improved Forms overview page display on mobile devices.
- Fixed: Improved Tools pages display on mobile devices.
- Fixed: Custom Captcha settings were duplicated on the Form Builder when the field was added through the Settings > Spam and Security screen.
- Fixed: Localization issues were present on the Get Started screen.
- Fixed: Subscriptions made by the Stripe Link payment method before 1.8.6.
- Fixed: Some non-optimized MySQL requests locked the database for seconds on huge sites with thousands of tables.
- Fixed: The Appearance of multiple dropdown values was incorrect.
- Fixed: Some information was missing if Smart Tags were processed in the background via cron.
- Fixed: The recent Chrome version for Windows was not displaying the custom scrollbars correctly.
- Fixed: `wpforms_plaintext_field_value` filter was unavailable since 1.8.5 version.
- Fixed: The form submission triggered an error on sites with long-term page caching.

= 1.8.6.4 =
- Fixed: Term notice was removed under the Stripe Credit Card field when Payment Elements were used.
- Fixed: An additional spinner appeared when the Setup panel button was clicked again.
- Fixed: Overflow of `img`, `video`, `canvas` and `svg` tags has been set to `clip` by default, as recommended by Google PageSpeed Insights.

= 1.8.6.3 =
- Fixed: The Name field was not clickable with Classic Markup and Base Styles.

[See changelog for all versions](https://plugins.svn.wordpress.org/wpforms-lite/trunk/changelog.txt).
