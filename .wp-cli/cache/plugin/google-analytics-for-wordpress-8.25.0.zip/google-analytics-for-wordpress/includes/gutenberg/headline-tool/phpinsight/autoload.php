<?php

/*
 * This file is part of the RNCryptor package.
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

require __DIR__ . '/lib/PHPInsight/Autoloader.php';

PHPInsight\Autoloader::register();
