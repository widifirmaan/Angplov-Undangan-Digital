const $ = require( "jquery" );

window.$ = $;
