<?php

//Empty
//This eliminates the default comments form for wordpress

?>