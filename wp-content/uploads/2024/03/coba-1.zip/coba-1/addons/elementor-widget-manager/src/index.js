import Settings from './setting';
const { render } = wp.element;


render( <Settings />, document.getElementById( 'ewm-setting-root' ) );
